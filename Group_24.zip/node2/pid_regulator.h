/**
 * @file pid_regulator.h
 *
 * @brief Software-implemented PID regulation scheme.
 *
 * Among the practical considerations taken in this module are:
 * - Derivative action on sample.
 * - Built-in derivative action low-pass filter.
 * - Integral anti windup.
 * - Mandatory output claming.
 *
 * @warning This module uses IEEE 754 floating point arithmetic.
 * Performance may be reduced on architectures that do not come
 * with a built-in Floating Point Unit (FPU), as software
 * emulation is then required.
 */
#ifndef PID_REGULATOR_H
#define PID_REGULATOR_H

typedef struct {
    /* Gains */
    float k_p;
    float k_i;
    float k_d;

    /* Sample time */
    float t;

    /* Derivative low-pass filter time constart */
    float tau;

    /* Integrator limits */
    float integral_min;
    float integral_max;

    /* Output clamping */
    float u_min;
    float u_max;

    /* Output bias */
    float u_bias;

    /* Previous steps */
    float integrator;
    float differentiator;
    float prev_sample;
    float prev_error;
} Pid;

/**
 * @brief Create a new PID regulator struct. This struct is
 * used in all calls to @c pid_regulator_step. Use this call
 * instead of manually creating a Pid type, as this call sets
 * certain internal parameters.
 *
 * @return A newly created PID regulator struct.
 */
Pid pid_regulator_new();

/**
 * @brief Step the PID regulator one step forward in time, doing
 * all the necessary integration, derivation, and finally returning
 * the commanded force from the PID regulator scheme.
 *
 * @param p_pid Pointer to a PID regulator struct.
 * @param set_point Commanded PID set point.
 * @param sample Most recent process sample.
 *
 * @return Commanded PID regulator force.
 */
float pid_regulator_step(Pid * p_pid, float set_point, float sample);

#endif
