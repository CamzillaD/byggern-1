/**
 * @file servo.h
 *
 * @brief Servo module, used to control the gimbal
 * angle of the game board.
 */
#ifndef SERVO_H
#define SERVO_H
#include <stdint.h>

/**
 * @brief Initialize the servo and its underlying resources.
 *
 * Required resources:
 * - PMC (Peripheral Management Controller) peripheral ID 27.
 * - Timer/Counter 0.
 * - Timer/Counter 0 channel 0 external pins.
 */
void servo_init();

/**
 * @brief Command a servo gimbal angle, given by @p gimbal.
 * A value of 0x00 is taken to mean maximum counter-clockwise
 * rotation, while a value of 0xff is taken to mean maximum
 * clockwise rotation. 0x7f indicates the neutral angle.
 *
 * @param gimbal Commanded servo gimbal angle.
 */
void servo_command_gimbal(uint8_t gimbal);

#endif
