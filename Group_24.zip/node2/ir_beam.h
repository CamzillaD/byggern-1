/**
 * @file ir_beam.h
 *
 * @brief Infrared detection beam interface.
 */
#ifndef IR_BEAM_H
#define IR_BEAM_H
#include <stdint.h>

/**
 * @brief Initialize the IR beam and its required resources.
 *
 * Required resources:
 * - PMC (Power Management Controller) peripheral ID 37.
 * - ADC peripheral.
 */
void ir_beam_init();

/**
 * @brief Check if the IR beam has been broken or not.
 *
 * @return 1 if the IR beam is currently broken, 0 if not.
 *
 * @warning Values returned by this function can safely be
 * expected to be reasonably accurate, owing to an internal
 * consensus filter.
 */
uint8_t ir_beam_broken();

#endif
