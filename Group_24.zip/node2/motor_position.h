/**
 * @file motor_position.h
 *
 * @brief Motor position regulation module.
 */
#ifndef MOTOR_POSITION_H
#define MOTOR_POSITION_H
#include <stdint.h>

/**
 * @brief Initialize the motor position regulation software.
 *
 * Internally, the ARM SysTick IP is used to ensure a uniform
 * and predictable time step for the underlying PID regulation
 * scheme.
 *
 * Required resources:
 * - SysTick
 */
void motor_position_init();

/**
 * @brief Request a new motor position set point. The position
 * requested by @p position ranges from 0x00, taken to mean
 * all the way to the left - to 0xff, taken to mean all the way
 * to the right.
 *
 * @param position Requested motor position.
 */
void motor_position_set_reference(uint8_t position);

/**
 * @brief Enable motor position tracking, i.e. the motor
 * will strive to attain the last requested position
 * set by a call to @c motor_position_set_reference.
 */
void motor_position_tracking_enable();

/**
 * @brief Disable motor position tracking, i.e. the motor
 * will ignore all requested position set points.
 */
void motor_position_tracking_disable();

#endif
