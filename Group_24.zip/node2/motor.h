/**
 * @file motor.h
 *
 * @brief Motor driver.
 */
#ifndef MOTOR_H
#define MOTOR_H
#include <stdint.h>

/**
 * @brief Initialize the motor and its underlying required
 * resources.
 *
 * Required resources:
 * - PMC (Power Management Controller) peripheral ID 38.
 * - DAC peripheral.
 * - Perpiheral PIO D output pins.
 */
void motor_init();

/**
 * @brief Command a given motor speed. A @p speed value
 * of 0x00 corresponds to maximum speed in the right direction,
 * while a value of 0xff corresponds to maximum speed in the
 * left direction. Both 0x7f and 0x80 are taken to mean full stop.
 *
 * @param speed Speed commanded from the motor.
 */
void motor_command_speed(uint8_t speed);

#endif
