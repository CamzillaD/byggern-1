/**
 * @file solenoid.h
 *
 * @brief Solenoid driver.
 */
#ifndef SOLENOID_H
#define SOLENOID_H

/**
 * @brief Initialize the solenoid and its underlying resources.
 *
 * Required resources:
 * - Peripheral PIO C pin 12.
 */
void solenoid_init();

/**
 * @brief Activate the solenoid.
 */
void solenoid_activate();

/**
 * @brief Deactivate the solenoid.
 */
void solenoid_deactivate();

#endif
