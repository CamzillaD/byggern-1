/**
 * @file internode.h
 *
 * @brief Internode communication interface module.
 */
#ifndef INTERNODE_H
#define INTERNODE_H
#include <stdint.h>

typedef enum {
    INTERNODE_COMMAND_SPEED,
    INTERNODE_COMMAND_POSITION
} InternodeCommandType;

typedef struct {
    /**
     * @brief Indicates whether the controlling node
     * has requested that the solenoid should be active (1),
     * or inactive (0).
     */
    uint8_t solenoid;

    /**
     * @brief Contrains the controlling node's requested speed
     * (if @p command_type is INTERNODE_COMMAND_SPEED), or
     * requested position (if @p command_type is
     * INTERNODE_COMMAND_POSITION).
     *
     * Maximum left speed/position is given by 0x00, maximum
     * right speed/position is given by 0xff, and neutral position/
     * no speed command is given by 0x7f.
     */
    uint8_t position_or_speed;

    /**
     * @brief Contains the controlling node's requested gimbal
     * servo position. Ranges from maximum counter-clockwise
     * rotation (0x00), to a maximum clockwise rotation (0xff).
     * Intermediate values are linearly interpolated; neutral
     * is given by 0x7f.
     */
    uint8_t servo;

    /**
     * @brief Indicates whether the controlling node
     * is requesting a set position (INTERNODE_COMMAND_POSITION),
     * or a set speed (INTERNODE_COMMAND_SPEED).
     */
    InternodeCommandType command_type;
} InternodeCommand;

/**
 * @brief External singleton command struct, accessible to the
 * main function of the application, as well as the internode
 * communication interface.
 */
extern InternodeCommand g_COMMAND;

/**
 * @brief Inform the controlling node that the current game
 * has been lost.
 *
 * @warning This function depends on the CAN interface; a
 * call to @c can_init must be made before invoking this
 * function.
 */
void internode_end_game();

#endif
