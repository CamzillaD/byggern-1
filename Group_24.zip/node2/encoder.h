/**
 * @file encoder.h
 *
 * @brief Encoder interface module.
 */
#ifndef ENCODER_H
#define ENCODER_H
#include <stdint.h>

/**
 * @brief Initialize the encoder and its underlying resources.
 *
 * Required resources:
 * - PMC (Power Management Controller) for peripheral ID 13.
 * - Peripheral PIO C input pins.
 * - Perpiheral PIO D output pins.
 */
void encoder_init();

/**
 * @brief Reset the encoder so that future measurements will
 * be relative to the position the encoder had when this
 * function was invoked.
 */
void encoder_reset();

/**
 * @brief Inquire the encoder about its current position
 * measurement.
 *
 * @return The current encoder value.
 */
uint16_t encoder_read();

#endif
