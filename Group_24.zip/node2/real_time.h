/**
 * @file real_time.h
 *
 * @brief Simple real time module.
 */
#ifndef REAL_TIME_H
#define REAL_TIME_H
#include <stdint.h>

/**
 * @brief Initialize the Real Time module. An internal
 * tick-rate of 125 ms is set.
 *
 * Required resources:
 * - RTT peripheral.
 */
void real_time_init();

/**
 * @brief Inquires the Real Time module about whether a
 * 125 ms tick has occured since last it was inquired.
 *
 * @return 1 if a tick of 125 ms has occured since last
 * this function was called; otherwise 0.
 */
uint8_t real_time_incremented();

#endif
