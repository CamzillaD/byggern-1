/**
 * @file system_reset.h
 *
 * @brief System reset module.
 */
#ifndef SYSTEM_RESET_H
#define SYSTEM_RESET_H

/**
 * @brief Force a system reset by writing a reset command
 * to the ARM Cortex Application Interrupt and Reset Control
 * Register (AIRCR). A reset is performed on the next
 * clock cycle.
 */
void system_reset();

#endif
