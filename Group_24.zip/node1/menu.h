/**
 * @file menu.h
 *
 * @brief Menu system interface.
 */
#ifndef MENU_H
#define MENU_H
#include <stdint.h>

typedef uint8_t (* MenuItemFunction)();

typedef struct MenuItem_s {
    /**
     * @brief C-string giving the title of the menu item.
     */
    const char * title;

    /**
     * @brief Pointer to the menu item's parent menu item.
     */
    struct MenuItem_s * p_parent;

    /**
     * @brief Pointer to the menu item's first child.
     */
    struct MenuItem_s * p_child;

    /**
     * @brief Pointer to a menu item's (next) sibling.
     */
    struct MenuItem_s * p_sibling;

    /**
     * @brief Action to be performed by leaf nodes, i.e.
     * nodes that do not contain submenues.
     */
    MenuItemFunction action;
} MenuItem;

/**
 * @brief Retrieve a pointer to the root node of the menu
 * system. This pointer may then be used in calls to @c menu_print.
 *
 * @return Pointer to the root node of the menu system.
 */
const MenuItem * menu_root_node();

/**
 * @brief Inquire about the children of a menu item.
 *
 * This function determines how many children the node pointed to
 * by @p p_node has. At return, *@p pp_child will have been altered
 * to point to *@p p_node's first child, while the number of
 * children it has is returned.
 *
 * @param[in] p_node Pointer to a menu item node.
 * @param[out] pp_child Pointer to a pointer of a menu item.
 *
 * @return The number of children that *@p p_node has.
 */
uint16_t menu_children(const MenuItem * p_node, MenuItem ** pp_child);

/**
 * @brief Print the menu given by *@p p_node to the display. The
 * level indicated by @p selected_level will be highlighted on the
 * display.
 *
 * @param p_node Pointer to a menu item representing a (sub)menu.
 * @param selected_level Selected level of (sub)menu alternatives.
 *
 * @warning This function depends on the display driver. Hence, a
 * call to @c display_init must be made before this function will
 * work as expected.
 */
void menu_print(const MenuItem * p_node, uint8_t selected_level);

#endif
