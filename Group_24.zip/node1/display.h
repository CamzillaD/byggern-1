/**
 * @file display.h
 *
 * @brief Display device driver.
 */
#ifndef DISPLAY_H
#define DISPLAY_H
#include <stdint.h>

/**
 * @brief Initilize the display. Must be invoked before
 * any other functions in this API can be called successfully.
 */
void display_init();

/**
 * @brief Clear the display of all activated pixels. After
 * this call returns, the display will be completely black.
 */
void display_clear();

/**
 * @brief Print a line to the display.
 *
 * The string given by @p string will be printed to line @p line
 * of the display, where @p line may take on values between 0 and
 * 7, inclusive. If @p arrow is a truthy value (non-zero), an
 * ASCII arrow ("->") will be inserted in front of @p string;
 * otherwise, the string will be printed unaltered.
 *
 * @param line Line on which to print @p string.
 * @param string String to print.
 * @param arrow Indicates whether an arrow ("->") should be
 * printed in front of @p string or not.
 *
 * @warning @p string is expected to be a valid C-string, i.e.
 * it must be '\0'-terminated.
 */
void display_print(uint8_t line, const char * string, uint8_t arrow);

/**
 * @brief Print an unsigned number given by @p number, on
 * line @p line of the display.
 *
 * @param line Line on which to print @p number.
 * @param number Number to be printed at line @p line.
 */
void display_print_number(uint8_t line, uint16_t number);

#endif
